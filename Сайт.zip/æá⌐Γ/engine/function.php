<?php
function check($value, $name, $pattern)
{
	if (!empty($_POST["$value"]))
	{	
		
		$field = $_POST["$value"];
		if (!preg_match($pattern, $field)) {
			die('Неккоректный ввод: ' . $name);
		}

	} else die('Пустое поле: ' . $name);
	
	return $field;
}

