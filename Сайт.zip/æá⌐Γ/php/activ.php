<?php
include_once "../engine/connect.php";

if (isset($_POST['submit']))
{
	$log = $_POST['login'];
	$pas = $_POST['password'];

	$query = $connect->query(" SELECT 'password' FROM 'user' WHERE 'login' = '$log'; ");
	$res = mysqli_fetch_assoc($query);
	
	if ($res['password'] == ($_POST['password']))
	{
		require_once('../office.html');
	}	else die('<br>Неверный ввод логина или пароля');
}
