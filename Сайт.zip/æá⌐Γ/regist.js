

/*document.getElementById("ler").addEventListener("click", function(e) {

document.getElementById('tex').innerHTML =" <form method='post' action='php/registration.php'>
<h2> Регистрация </h2>
<input type='text' 	name='name'   placeholder='Имя' required><br>
<input type='text' 	name='surname'    placeholder='Фамилия' required><br>
<input type='text' 	name='patronymic'  placeholder='Отчество' required'><br>
<input type='email' name='email' placeholder='E-mail' required><br>
<input type='password' name='password'  placeholder='Пароль' required><br>
<input type='text' 	name='login'  placeholder='Логин' required><br>


<input class='ghost-button' type='submit' name='submit' value='ОТПРАВИТЬ ФОРМУ'>
";


})*/
 function disp(form) {
        if (form.style.display == "none") {
            form.style.display = "block";
        } else {
            form.style.display = "none";
        }
    }